Sociocracy 3.0 Illustrations
----------------------------


This package contains many of the illustrations I have created for Sociocracy 3.0 (a.k.a. S3), including all illustrations used in "S3 - A Practical Guide"

The package has a website at https://illustrations.sociocracy30.org and a Github Repository https://github.com/S3-working-group/s3-illustration

The illustrations are available as png files with 140dpi, both with white and transparent backgrounds, in English and German versions, more languages will be available soon. 

This work, "Sociocracy 3.0 Illustrations" by Bernhard Bockelbrink is licensed under a Creative Commons Attribution-ShareAlike 4.0 International License. You can read the full license in the document LICENSE, or online at https://creativecommons.org/licenses/by-sa/4.0/